# Cloudy GTK Themes
Gtk2, Gtk3, Gnome Shell, Cinnamon & Metacity themes base on [Arc-Theme](https://github.com/horst3180/arc-theme) </br>
License : [GPLv3](https://choosealicense.com/licenses/gpl-3.0/)</br></br>
Theme can be download [here](https://www.pling.com/p/1242416/)</br></br>
SCREENSHOTS:</br>
![cloudyscreenshot](https://i.ibb.co/D847MzY/cloudy-screenshot-001.png "cloudy screenshot")</br></br>
![cloudyscreenshot](https://i.ibb.co/XVKFDYq/cloudy-soft-screenshot.png "cloudy screenshot")</br>
